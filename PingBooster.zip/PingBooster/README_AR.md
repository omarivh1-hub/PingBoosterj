# مُحسّن البنج (PingBooster)

تطبيق أندرويد بسيط (Java/XML من غير مكتبات خارجية) فيه:

1. قياس البنج (Ping) والـ Jitter وفقد الحزم لسيرفرات في مناطق مختلفة، أو لأي عنوان تكتبه.
2. فحص الواي فاي (التردد 2.4/5 جيجا، قوة الإشارة، سرعة الربط).
3. نسخ عنوان DNS خاص (Google / Cloudflare / Quad9) وفتح الإعدادات لتفعيله.
4. اختصارات لعدم الإزعاج وقفل التطبيقات الخلفية + نصايح قبل اللعب.

ملحوظة مهمة: التطبيق مش بيقلل البنج بشكل سحري. هو بيساعدك تعرف مشكلتك فين وتظبط اللي في إيدك.

## بناء الـ APK من الموبايل بدون كمبيوتر (عن طريق GitHub)

محتاج حساب GitHub مجاني ومتصفح على الموبايل.

1. اعمل حساب على github.com وسجل دخول.
2. اعمل Repository جديد (New repository) باسم PingBooster، واختار Public، وفعّل "Add a README file".
3. ادخل على الـ Repository ← Add file ← Upload files ← ارفع ملف PingBooster.zip (الملف كله زي ما هو، من غير ما تفكه) ← Commit changes.
4. ارجع للـ Repository ← Add file ← Create new file.
   - في خانة الاسم اكتب بالظبط: .github/workflows/build.yml
   - الصق محتوى ملف الـ workflow (موجود في الرسالة اللي بعتهالك Claude، أو تحت).
   - اضغط Commit changes.
5. افتح تبويب Actions ← هتلاقي "Build APK" شغال لوحده (لو لأ: اختاره واضغط Run workflow).
6. استنى 3 إلى 6 دقايق لحد ما تظهر علامة صح خضرا.
7. افتح آخر تشغيل ← انزل لتحت لقسم Artifacts ← نزّل PingBooster-debug-apk.
   (لو مش ظاهر في الموبايل، فعّل "Desktop site" من قائمة المتصفح.)
8. هينزل ملف ZIP. فكه من تطبيق الملفات، هتلاقي جواه ملف app-debug.apk.
9. اضغط عليه وثبّته. لو طلب منك، فعّل "التثبيت من مصادر غير معروفة" للمتصفح أو لتطبيق الملفات.

## محتوى ملف الـ workflow

```yaml
name: Build APK

on:
  workflow_dispatch:
  push:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Unzip project
        run: unzip -q PingBooster.zip

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'

      - name: Build debug APK
        working-directory: PingBooster
        run: gradle assembleDebug --no-daemon

      - uses: actions/upload-artifact@v4
        with:
          name: PingBooster-debug-apk
          path: PingBooster/app/build/outputs/apk/debug/*.apk
```

## لو حصل خطأ في البناء

افتح التشغيل اللي فشل في تبويب Actions، وانسخ آخر 20 سطر من الـ log وابعتهم لـ Claude وهيصلحهم.

## تفعيل DNS الخاص يدوياً

الإعدادات ← الشبكة والإنترنت (أو الاتصال والمشاركة) ← DNS الخاص ← اسم مضيف مزود DNS الخاص، واكتب واحد من:

- dns.google
- 1dot1dot1dot1.cloudflare-dns.com
- dns.quad9.net
