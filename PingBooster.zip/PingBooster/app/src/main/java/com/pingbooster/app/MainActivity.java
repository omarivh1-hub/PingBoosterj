package com.pingbooster.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int ATTEMPTS = 10;
    private static final int TIMEOUT_MS = 2000;

    // {الاسم، العنوان} - القياس على بورت 443
    private static final String[][] SERVERS = {
            {"البحرين (الشرق الأوسط)", "ec2.me-south-1.amazonaws.com"},
            {"الإمارات (الشرق الأوسط)", "ec2.me-central-1.amazonaws.com"},
            {"فرانكفورت (أوروبا)", "ec2.eu-central-1.amazonaws.com"},
            {"أيرلندا (أوروبا)", "ec2.eu-west-1.amazonaws.com"},
            {"Cloudflare", "1.1.1.1"},
            {"Google", "8.8.8.8"},
    };

    private TextView tvPing;
    private TextView tvWifi;
    private EditText etHost;
    private Button btnTestAll;
    private Button btnTestCustom;

    private volatile boolean running = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvPing = findViewById(R.id.tvPing);
        tvWifi = findViewById(R.id.tvWifi);
        etHost = findViewById(R.id.etHost);
        btnTestAll = findViewById(R.id.btnTestAll);
        btnTestCustom = findViewById(R.id.btnTestCustom);

        btnTestAll.setOnClickListener(v -> {
            List<String[]> targets = new ArrayList<>();
            for (String[] s : SERVERS) {
                targets.add(new String[]{s[0], s[1], "443"});
            }
            startTest(targets);
        });

        btnTestCustom.setOnClickListener(v -> testCustomHost());

        findViewById(R.id.btnWifi).setOnClickListener(v -> checkNetwork());

        findViewById(R.id.btnDnsGoogle).setOnClickListener(v ->
                copyAndOpenDns("dns.google"));
        findViewById(R.id.btnDnsCloudflare).setOnClickListener(v ->
                copyAndOpenDns("1dot1dot1dot1.cloudflare-dns.com"));
        findViewById(R.id.btnDnsQuad9).setOnClickListener(v ->
                copyAndOpenDns("dns.quad9.net"));

        findViewById(R.id.btnDnd).setOnClickListener(v ->
                openSettings("android.settings.ZEN_MODE_PRIORITY_SETTINGS"));
        findViewById(R.id.btnApps).setOnClickListener(v ->
                openSettings(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS));
    }

    // ---------------------------------------------------------------
    // 1) قياس البنج
    // ---------------------------------------------------------------

    private void testCustomHost() {
        String raw = etHost.getText().toString().trim();
        if (raw.isEmpty()) {
            toast("اكتب عنوان السيرفر الأول");
            return;
        }
        raw = raw.replaceFirst("^[a-zA-Z]+://", "");
        int slash = raw.indexOf('/');
        if (slash >= 0) {
            raw = raw.substring(0, slash);
        }
        String host = raw;
        int port = 443;
        int colon = raw.lastIndexOf(':');
        if (colon > 0) {
            try {
                port = Integer.parseInt(raw.substring(colon + 1));
                host = raw.substring(0, colon);
            } catch (NumberFormatException e) {
                toast("البورت مش مظبوط");
                return;
            }
        }
        if (host.isEmpty() || port < 1 || port > 65535) {
            toast("العنوان مش مظبوط");
            return;
        }
        List<String[]> targets = new ArrayList<>();
        targets.add(new String[]{"عنوان مخصص", host, String.valueOf(port)});
        startTest(targets);
    }

    private void startTest(final List<String[]> targets) {
        if (running) {
            toast("الاختبار شغال، استنى لما يخلص");
            return;
        }
        running = true;
        setButtonsEnabled(false);
        tvPing.setText("جاري القياس... (كل منطقة بتاخد حوالي ثانيتين)\n\n");

        new Thread(() -> {
            for (String[] t : targets) {
                int port;
                try {
                    port = Integer.parseInt(t[2]);
                } catch (NumberFormatException e) {
                    port = 443;
                }
                final String result = measure(t[0], t[1], port);
                runOnUiThread(() -> tvPing.append(result + "\n"));
            }
            running = false;
            runOnUiThread(() -> {
                tvPing.append("خلص القياس.\n");
                setButtonsEnabled(true);
            });
        }).start();
    }

    private void setButtonsEnabled(boolean enabled) {
        btnTestAll.setEnabled(enabled);
        btnTestCustom.setEnabled(enabled);
    }

    /** يقيس زمن فتح اتصال TCP كذا مرة ويحسب المتوسط والـ Jitter وفقد الحزم. */
    private String measure(String label, String host, int port) {
        InetSocketAddress addr = new InetSocketAddress(host, port);
        if (addr.isUnresolved()) {
            return label + " (" + host + ")\n"
                    + "   مقدرتش أوصل للعنوان ده. تأكد من الاسم ومن اتصال النت.\n";
        }

        List<Long> times = new ArrayList<>();
        int failed = 0;
        for (int i = 0; i < ATTEMPTS; i++) {
            Socket socket = new Socket();
            long start = System.nanoTime();
            try {
                socket.connect(addr, TIMEOUT_MS);
                times.add((System.nanoTime() - start) / 1000000L);
            } catch (Exception e) {
                failed++;
            } finally {
                try {
                    socket.close();
                } catch (Exception ignored) {
                }
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException ie) {
                break;
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append(label).append(" (").append(host).append(")\n");

        if (times.isEmpty()) {
            sb.append("   كل المحاولات فشلت (فقد 100%)\n");
            return sb.toString();
        }

        long sum = 0;
        long min = Long.MAX_VALUE;
        long max = 0;
        for (long t : times) {
            sum += t;
            if (t < min) min = t;
            if (t > max) max = t;
        }
        long avg = sum / times.size();

        long jitterSum = 0;
        for (int i = 1; i < times.size(); i++) {
            jitterSum += Math.abs(times.get(i) - times.get(i - 1));
        }
        long jitter = times.size() > 1 ? jitterSum / (times.size() - 1) : 0;
        int lossPercent = failed * 100 / ATTEMPTS;

        sb.append(String.format(Locale.US,
                "   المتوسط: %d ms  |  الأقل: %d  |  الأعلى: %d%n", avg, min, max));
        sb.append(String.format(Locale.US,
                "   Jitter: %d ms  |  فقد الحزم: %d%%%n", jitter, lossPercent));
        sb.append("   التقييم: ").append(rate(avg, jitter, lossPercent)).append("\n");
        return sb.toString();
    }

    private String rate(long avg, long jitter, int loss) {
        if (loss >= 20 || avg >= 200) return "ضعيف";
        if (loss >= 5 || avg >= 120 || jitter >= 40) return "مقبول";
        if (avg >= 60 || jitter >= 20) return "جيد";
        return "ممتاز";
    }

    // ---------------------------------------------------------------
    // 2) فحص الشبكة
    // ---------------------------------------------------------------

    @SuppressWarnings("deprecation")
    private void checkNetwork() {
        StringBuilder sb = new StringBuilder();

        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();

        if (ni == null || !ni.isConnected()) {
            tvWifi.setText("مفيش اتصال بالإنترنت دلوقتي.");
            return;
        }

        if (ni.getType() == ConnectivityManager.TYPE_WIFI) {
            WifiManager wm = (WifiManager) getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            WifiInfo wi = wm == null ? null : wm.getConnectionInfo();
            if (wi == null) {
                tvWifi.setText("متصل بواي فاي، لكن مقدرتش أقرا بياناته.");
                return;
            }

            int freq = wi.getFrequency();
            int rssi = wi.getRssi();
            int speed = wi.getLinkSpeed();

            sb.append("النوع: واي فاي\n");

            String band;
            if (freq >= 5900) {
                band = "6 GHz (ممتاز)";
            } else if (freq >= 4900) {
                band = "5 GHz (أحسن للألعاب)";
            } else if (freq > 0) {
                band = "2.4 GHz (مزدحم ومعرض للتشويش، جرب 5GHz لو الراوتر بيدعمه)";
            } else {
                band = "غير معروف";
            }
            sb.append("التردد: ").append(band).append("\n");

            String signal;
            if (rssi >= -55) signal = "ممتازة";
            else if (rssi >= -67) signal = "جيدة";
            else if (rssi >= -80) signal = "ضعيفة، قرّب من الراوتر";
            else signal = "ضعيفة جداً، قرّب من الراوتر";
            sb.append("قوة الإشارة: ").append(rssi).append(" dBm (").append(signal).append(")\n");

            if (speed > 0) {
                sb.append("سرعة الربط: ").append(speed).append(" Mbps\n");
            }
        } else {
            sb.append("النوع: بيانات الموبايل");
            String sub = ni.getSubtypeName();
            if (sub != null && !sub.isEmpty()) {
                sb.append(" (").append(sub).append(")");
            }
            sb.append("\nالواي فاي عادةً أثبت من بيانات الموبايل في الألعاب.");
        }

        tvWifi.setText(sb.toString());
    }

    // ---------------------------------------------------------------
    // 3) DNS
    // ---------------------------------------------------------------

    private void copyAndOpenDns(String hostname) {
        try {
            ClipboardManager cb =
                    (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cb != null) {
                cb.setPrimaryClip(ClipData.newPlainText("dns", hostname));
            }
            toast("اتنسخ: " + hostname);
        } catch (Exception e) {
            toast("مقدرتش أنسخ العنوان، اكتبه بإيدك: " + hostname);
        }
        openSettings(Settings.ACTION_WIRELESS_SETTINGS);
    }

    // ---------------------------------------------------------------
    // مساعدات
    // ---------------------------------------------------------------

    private void openSettings(String action) {
        try {
            startActivity(new Intent(action));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception e2) {
                toast("مقدرتش أفتح الإعدادات");
            }
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
